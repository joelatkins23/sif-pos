<?php
include ("config.php");
echo SITENOME;
?>