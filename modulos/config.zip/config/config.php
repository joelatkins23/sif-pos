<?php 
//CONFIGURAÇÃO GERAl
define(SITENOME,'Equipe G12');
define(SITELOGOPNG,'http://www.vitoriaregiacursos.com.br/static/logo10.png');
define(TITULO,'Equipe G12');
define(DESCRICAO,'descricao para o site');
define(TAGS,'palavras, chaves');
define(AUTOR,'D Art Web www.dartweb.com.br');
define(VERSAO,'3.0');

//LINK
define(LINK,'http://www.equipeg12.com.br/');

//LINK SEM HTTP
define(LINKSEMHTTP,'www.equipeg12.com.br');

//URL DO PROJETO
define(URL,'http://www.equipeg12.com.br/admin/');

//URL DO PAINEL
define(PAINEL,'http://www.equipeg12.com.br/painel/dartweb/');

//URL DO PAINEL LOGIN
define(PAINELLOGIN,'http://www.equipeg12.com.br/painel');

//CONFIG BANCO DE DADOS
define(HOST,'localhost');
define(USER,'equipeg1_padrao');
define(PASS,'731910');
define(BANCO,'equipeg1_banco');

//CONFIG GOOGLE A
define(GUSER,'contato@equipeg12.com.br');
define(GPASS,'bruninhah123');

//E-MAIL
define(MAILHOST,'mail.equipeg12.com.br');
define(MAILUSER,'contato@equipeg12.com.br');
define(MAILPASS,'123456');
define(MAILPORT,'110');


//SUPORTE
define(SUPORTEMAILUSER,'dartweb@equipeg12.com.br');
define(NCLINK,'http://www.equipeg12.com.br/painel/dartweb/modulos/notificacoes/enviarMsg.php');

//CONFIGURAÇÕES DA LOJA VIRTUAL
define(EMAILMINHACONTA,'http://www.equipeg12.com.br/painel');
define(EMAILMEUSPEDIDOS,'http://www.equipeg12.com.br/painel');
define(EMAILATENDIMENTO,'http://www.equipeg12.com.br/contato');
define(EMAILlOGOMARCA,'http://www.equipeg12.com.br/static/logo10.png');
define(EMAILTOPOCOLOR,'8b2a9e');
define(EMAILRODAPE,'Loja Vitória Régia | 66.9610-3694 <br/>  contato@vitoriaregiacursos.com.br | www.vitoriaregiacursos.com.br');
define(LINKPRODUTO,'http://www.equipeg12.com.br/');
define(ICONEFACEBOOK,'http://www.equipeg12.com.br/static/icone-facebook.png');
define(LINKFACEBOOK,'http://LINK-DO-MEU-FACE');
define(ICONETWITTER,'http://www.equipeg12.com.br/static/icone-twitter.png');
define(LINKTWITTER,'http://LINK-DO-MEU-TWITTER');


?>